package gnula

import com.lagradost.cloudstream3.*

class GnulaProvider : MainAPI() {
    override val name: String
        get() = "Gnula"
    override val mainUrl: String
        get() = "https://gnula.nu"

    // Implementación de métodos necesarios
}