package hentaiLA

import com.lagradost.cloudstream3.*

class HentaiLAProvider : MainAPI() {
    override val name: String
        get() = "HentaiLA"
    override val mainUrl: String
        get() = "https://hentaila.com"

    // Implementación de métodos necesarios
}